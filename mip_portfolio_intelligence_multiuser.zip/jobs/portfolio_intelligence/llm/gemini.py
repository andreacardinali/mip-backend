import httpx
from jobs.portfolio_intelligence.llm.base import LLMProvider, LLMRequest, LLMResponse
from jobs.portfolio_intelligence.llm.parsing import parse_json_object

class GeminiProvider(LLMProvider):
    def __init__(self, api_key: str, model: str, timeout: float=60):
        self.api_key=api_key; self.model=model; self.timeout=timeout
    def generate_json(self, request: LLMRequest) -> LLMResponse:
        url=f"https://generativelanguage.googleapis.com/v1beta/models/{self.model}:generateContent"
        body={"contents":[{"role":"user","parts":[{"text":request.prompt}]}],
              "generationConfig":{"temperature":request.temperature,"maxOutputTokens":request.max_tokens,"responseMimeType":"application/json"}}
        if request.response_schema: body["generationConfig"]["responseSchema"]=request.response_schema
        if request.grounded_search: body["tools"]=[{"google_search":{}}]
        with httpx.Client(timeout=self.timeout) as client:
            response=client.post(url, headers={"x-goog-api-key":self.api_key,"Content-Type":"application/json"}, json=body)
            response.raise_for_status(); raw=response.json()
        candidate=(raw.get("candidates") or [None])[0]
        if not candidate: raise RuntimeError("Gemini returned no candidate")
        if candidate.get("finishReason") not in {None,"STOP"}: raise RuntimeError(f"Gemini incomplete response: {candidate.get('finishReason')}")
        parts=[p for p in candidate.get("content",{}).get("parts",[]) if not p.get("thought") and p.get("text")]
        data=parse_json_object("\n".join(p["text"] for p in parts))
        metadata=candidate.get("groundingMetadata") or {}
        chunks=metadata.get("groundingChunks") or []
        sources=[]
        for n, chunk in enumerate(chunks):
            web=chunk.get("web") or {}
            if web.get("uri") or web.get("title"):
                sources.append({"sourceIndex":n,"title":web.get("title"),"uri":web.get("uri")})
        return LLMResponse(data=data,raw=raw,sources=sources,search_executed=bool(metadata.get("webSearchQueries") or sources))
