from datetime import datetime, timezone
from jobs.portfolio_intelligence.notifications.telegram import TelegramNotifier
class NotificationService:
    def __init__(self, repo, notifier: TelegramNotifier, send_enabled: bool): self.repo=repo; self.notifier=notifier; self.send_enabled=send_enabled
    def publish(self, *, notification_id, branch, entity_id, symbol, event_key, severity, title, message, context):
        if self.repo.exists(notification_id): return False
        status="DRY_RUN"; sent_at=None
        if self.send_enabled:
            self.notifier.send(message); status="SENT"; sent_at=datetime.now(timezone.utc)
        self.repo.insert(notification_id=notification_id,branch=branch,entity_id=entity_id,symbol=symbol,event_key=event_key,severity=severity,title=title,message=message,context=context,status=status,sent_at=sent_at)
        return True
