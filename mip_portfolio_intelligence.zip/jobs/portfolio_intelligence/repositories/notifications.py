import json
from datetime import datetime, timedelta, timezone
from sqlalchemy import text
from sqlalchemy.orm import Session

class NotificationRepository:
    def __init__(self, db: Session): self.db=db
    def exists(self, notification_id: str) -> bool:
        return bool(self.db.execute(text("SELECT 1 FROM portfolio_notification_history WHERE notification_id=:id AND status='SENT'"), {"id":notification_id}).scalar())
    def similar(self, branch: str, symbol: str|None, days: int=30, limit: int=10) -> list[dict]:
        return [dict(r) for r in self.db.execute(text("""
            SELECT notification_id, title, message, context, sent_at
            FROM portfolio_notification_history
            WHERE branch=:branch AND status='SENT'
              AND (:symbol IS NULL OR symbol=:symbol)
              AND sent_at >= :cutoff ORDER BY sent_at DESC LIMIT :limit
        """), {"branch":branch,"symbol":symbol,"cutoff":datetime.now(timezone.utc)-timedelta(days=days),"limit":limit}).mappings()]
    def insert(self, *, notification_id: str, branch: str, entity_id: str|None, symbol: str|None,
               event_key: str|None, severity: str, title: str, message: str,
               context: dict, status: str, sent_at: datetime|None):
        self.db.execute(text("""
            INSERT INTO portfolio_notification_history
            (notification_id, branch, entity_id, symbol, event_key, observed_at,
             severity, status, title, message, context, sent_at)
            VALUES (:notification_id,:branch,CAST(:entity_id AS uuid),:symbol,:event_key,now(),
                    :severity,:status,:title,:message,CAST(:context AS jsonb),:sent_at)
            ON CONFLICT (notification_id) DO UPDATE SET
              status=EXCLUDED.status, message=EXCLUDED.message, context=EXCLUDED.context,
              sent_at=EXCLUDED.sent_at, updated_at=now()
        """), {"notification_id":notification_id,"branch":branch,"entity_id":entity_id,
        "symbol":symbol,"event_key":event_key,"severity":severity,"status":status,
        "title":title,"message":message,"context":json.dumps(context,default=str),"sent_at":sent_at})
    def purge(self, days: int) -> int:
        result=self.db.execute(text("DELETE FROM portfolio_notification_history WHERE status='SENT' AND sent_at < :cutoff"), {"cutoff":datetime.now(timezone.utc)-timedelta(days=days)})
        return result.rowcount or 0
