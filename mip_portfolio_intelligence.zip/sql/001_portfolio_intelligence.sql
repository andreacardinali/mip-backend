BEGIN;
CREATE TABLE IF NOT EXISTS portfolio_notification_history (
    notification_id varchar(255) PRIMARY KEY,
    branch varchar(50) NOT NULL,
    entity_id uuid REFERENCES entities(entity_id) ON DELETE SET NULL,
    symbol varchar(50),
    event_key varchar(255),
    observed_at timestamptz,
    severity varchar(20) NOT NULL,
    status varchar(20) NOT NULL,
    title text,
    message text,
    context jsonb NOT NULL DEFAULT '{}'::jsonb,
    sent_at timestamptz,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_pnh_branch ON portfolio_notification_history(branch);
CREATE INDEX IF NOT EXISTS ix_pnh_symbol ON portfolio_notification_history(symbol);
CREATE INDEX IF NOT EXISTS ix_pnh_sent_at ON portfolio_notification_history(sent_at);
DROP TRIGGER IF EXISTS trg_portfolio_notification_history_timestamps ON portfolio_notification_history;
CREATE TRIGGER trg_portfolio_notification_history_timestamps
BEFORE INSERT OR UPDATE ON portfolio_notification_history
FOR EACH ROW EXECUTE FUNCTION trg_set_timestamps();
COMMIT;
